#!/bin/bash
# Run java with increased heap size
java -Xmx1024m -jar Paramorama2.jar